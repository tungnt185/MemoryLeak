namespace Sixeyed.Disposable.DomainConsoleApp
{
    public interface IApiClient
    {
        int GetWordCount(string input);
    }
}