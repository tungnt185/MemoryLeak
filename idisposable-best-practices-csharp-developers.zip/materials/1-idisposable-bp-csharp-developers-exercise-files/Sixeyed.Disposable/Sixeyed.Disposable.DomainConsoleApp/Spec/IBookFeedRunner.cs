﻿namespace Sixeyed.Disposable.DomainConsoleApp
{
    public interface IBookFeedRunner
    {
        void Start();
    }
}