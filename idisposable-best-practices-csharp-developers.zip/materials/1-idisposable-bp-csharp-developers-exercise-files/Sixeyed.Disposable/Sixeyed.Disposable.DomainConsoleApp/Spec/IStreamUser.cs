namespace Sixeyed.Disposable.DomainConsoleApp
{
    public interface IStreamUser
    {
        void CopyFile(string sourcePath, string targetPath);
    }
}